DJANGO_SETTINGS_MODULE=settings.local celery -A prj_dept flower
